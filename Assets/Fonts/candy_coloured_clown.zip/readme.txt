Thank you for downloading this font.  
If you wish to use this font commercially please deposit $15 to my paypal address at JWOODSNZ@gmail.com

Regards,
Jeremy Woods.